'''
Módulo de prueba
'''

print("Saludo desde el módulo de prueba")

def mock(valor):
    return "Me enviaste el valor {}".format(valor)

lista = [1,2,3,4,5,6,7,8,9]
