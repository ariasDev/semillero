const mongosse = require("../DBconection/MongoConection");
const colaborators = require("../Models/CollaboratorsModel");

exports.getCollaborator = async _ => {
    return await colaborators.find();
}

exports.getCollaboratorsByDate = async date => {
    return await colaborators.findById({fechaRegistro:date})
}


