const express = require("express");
const CollaboratorsService = require("../Services/CollaboratorsService");
const middelwere = require("../middlewares/error")
const constantes = require("../constantes");

exports.getCollaborators = async (req,res) => {
    const users = await CollaboratorsService.getCollaborator();
    if(users.length === 0)
        throw error(constantes.USER_NOT_FOUND,"no se encuentró");
    res.send(users);
}