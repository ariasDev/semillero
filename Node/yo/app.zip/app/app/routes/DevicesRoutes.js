const express = require("express");
const devicesRoutes = express.Router();

module.exports = devicesRoutes;