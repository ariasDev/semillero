const express = require("express");
const collaboratorsRoutes = express.Router();
const collaboratorsController = require("../Controllers/CollaboratorsController");

collaboratorsRoutes.get('/',collaboratorsController.getCollaborators);

module.exports = collaboratorsRoutes;