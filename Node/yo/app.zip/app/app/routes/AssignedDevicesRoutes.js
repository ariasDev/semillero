const express = require("express");
const assignedDevicesRoutes = express.Router();

module.exports = assignedDevicesRoutes;