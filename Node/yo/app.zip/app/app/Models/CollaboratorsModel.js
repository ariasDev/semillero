const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CollaboratorSchema = Schema({
    identificacion : Number,
    nombre:String,
    apellido: String,
    cargo: String,
    usuarioRed:String,
    estado: String,
    fechaRegistro: Number
})

module.exports = mongoose.model('colaborator',CollaboratorSchema);