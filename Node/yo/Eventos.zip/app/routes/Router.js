const express = require("express");
const router = express.Router();
const EventosController = require("../controllers/EventosController")
const SesionesController = require("../controllers/SesionesController")

router.get('/sesiones',SesionesController.getSesiones);
router.post('/sesiones/insertar',SesionesController.postSesiones);
router.post('/sesiones/insertarj', (req, res) => console.log("recibo",req));
router.get('/eventos',EventosController.getEventos);
router.post('po',EventosController.postEvento);
router.put('/sesiones/modificar',SesionesController.putSesiones);

module.exports = router;