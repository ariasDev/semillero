const express = require("express");
const app = express();

const dotenv = require("dotenv");
const cors = require("cors");
const bodyParser = require("body-parser");

dotenv.config();
app.set('port',process.env.PORT);
console.log(`app corriendo por el puerto ${process.env.PORT}`);

app.use(cors());
app.use(express.urlencoded({extended:false}));

const router = require("./routes/Router");

app.use('/', router);

app.listen(app.get('port'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}))

module.exports = app;