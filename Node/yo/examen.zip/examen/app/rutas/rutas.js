const express = require("express");
const router = express.Router();
const controller = require("../controlador/userController")

router.get('/:id',controller.getId);//ruta obtener por id
router.get('/',controller.getUsers);//ruta obtener todos los objetos de la colección
router.post('/insertar',controller.postUser)
router.delete('/delete/:id',controller.deleteUser)
router.patch('/update/:id',controller.patchUser)

module.exports = router;