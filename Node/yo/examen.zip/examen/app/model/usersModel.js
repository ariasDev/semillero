const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const userSchema = Schema({
    identificacion : {
        type: Number,
        unique:true
    },
    saldo : Number,
    credito :Number,
    nombre : String,
    apellido : String,
    direccion : String,
    tel : Number
})

module.exports = mongoose.model('user',userSchema);