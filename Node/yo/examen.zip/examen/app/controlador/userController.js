const express = require("express");
const router = express.Router();
const service = require("../servicio/usersService")


//función que llama al servicio para traer todos los objetos en la colección
exports.getUsers = async (req,res) => {
    const users = await service.getUsers();
    res.send(users);
}

//funcion que llama a el servicio para traer un objeto por id
exports.getId = async  (req,res) =>{
    try{
        const user = await service.getUserById(req.params.id);
        if (user.length === 0)
         res.status(404).send("not found")
        res.send(user);
    }catch(err){
        console.log(err)
    }
}

exports.postUser =  async (req,res, next) => {
    console.log("------------------> Entré post Controller")
    try{
        const collaboratorResponse = await service.saveUser(req);
        if(collaboratorResponse == false){
            res.status(400).send("Collaborator not created.")
        }
        res.send({message:"Collaborator Created"})

    }catch(err){
        next(err)
    }
}

exports.deleteUser =  async (req,res,next) => {
    try{

        const user = await service.getUserById(req.params.id);
        console.log(user)
        console.log(user[0].saldo)
        if(user[0].saldo === 0 ){
            const userToDelete = await service.deleteUser(req.params.id);
            console.log(userToDelete)

            if(userToDelete.n == 0){
                res.status(404).send({message:"Usuario no se puede eliminar"})
            }
            if(userToDelete.n == 1){
                res.send({message:"Usuario eliminado con exito"})
            }
        }
        res.status(404).send({message:"Usuario no se puede eliminar"})
         

    }catch(err){
        next(err);
    }
}

exports.patchUser = async (req, res, next) => {
    try {
        const user = await service.getUserById(req.params.id);
        console.log(user)
        console.log(user[0].credito)

        if( user[0].saldo > 0 || user[0].saldo <= 0 ){
            
            const collaboratorResponse = await service.updateCredito(req);

            let nuevo ={
                "identificacion": collaboratorResponse.identificacion,
                "saldo": (parseInt(user[0].saldo ) - parseInt(collaboratorResponse.credito)),
                "credito": (parseInt(user[0].credito ) - parseInt(collaboratorResponse.credito)),
                "nombre": collaboratorResponse.nombre,
                "apellido":collaboratorResponse.apellido,
                "direccion": collaboratorResponse.direccion,
                "tel": collaboratorResponse.tel,
            }

            res.send(nuevo) 
        }
        res.send({message:"so se puede actualizar el saldo"}) 
                
    } catch(err) {
        next(err)
    }
}