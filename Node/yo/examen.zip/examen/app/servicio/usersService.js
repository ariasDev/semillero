const mongoose = require("../DBconection/DBconection");
const userModel = require("../model/usersModel");

//metodo que trae todos los registros de la colección collaborators
exports.getUsers = async _ => {
    return await userModel.find();
}

//obtener un objeto json con el id seleccionado
exports.getUserById = async id => {
    const idTosearch = parseInt(id);
    return await userModel.find({identificacion:idTosearch},{identificacion:1,nombre:1,_id:0,saldo:1,credito:1});
}

exports.saveUser = collaboratorInfo => {
    console.log(collaboratorInfo);
    console.log("------------------> Entré post Service")
    const collaboratorToSave = new userModel({
        identificacion: collaboratorInfo.body.identificacion,
        saldo: collaboratorInfo.body.saldo,
        credito: collaboratorInfo.body.credito,
        nombre: collaboratorInfo.body.nombre,
        apellido: collaboratorInfo.body.apellido,
        direccion: collaboratorInfo.body.direccion,
        tel: collaboratorInfo.body.tel
    })
    console.log(collaboratorToSave)
    collaboratorToSave.save()
    .then(true)
    .catch(false);
}

exports.deleteUser = async id => {
    const idToDelete = parseInt(id)
    return await userModel.find({identificacion:idToDelete}).remove()
}

exports.updateCredito = async data => {
    
    return await userModel.findOneAndUpdate({identificacion: data.params.id}, 
        {$set: data.body},{new: true})
}